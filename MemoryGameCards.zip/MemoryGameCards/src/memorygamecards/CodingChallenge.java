package memorygamecards;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CodingChallenge extends JFrame {
    private JTextArea codeArea;
    private JButton submitButton;
    private MemoryGame memoryGame;

    public CodingChallenge() {
        this.memoryGame = memoryGame;
        setTitle("Coding Challenge");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        JLabel promptLabel = new JLabel("Write a method to check if a number is even or odd:");
        codeArea = new JTextArea(5, 30);
        submitButton = new JButton("Submit");

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkAnswer();
            }
        });

        JPanel panel = new JPanel();
        panel.add(new JScrollPane(codeArea));
        add(promptLabel, BorderLayout.NORTH);
        add(panel, BorderLayout.CENTER);
        add(submitButton, BorderLayout.SOUTH);
        setVisible(true);
    }

    private void checkAnswer() {
        String userCode = codeArea.getText().trim();
        // A simple check for the expected method signature
        if (userCode.contains("boolean isEven(int number)") && userCode.contains("return number % 2 == 0;")) {
            JOptionPane.showMessageDialog(this, "Correct! You can continue playing.");
            setVisible(false);
            new MemoryGame().setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Incorrect! Game Over.");
            setVisible(false);
            new StartGame().setVisible(true);
        }
    }

}
