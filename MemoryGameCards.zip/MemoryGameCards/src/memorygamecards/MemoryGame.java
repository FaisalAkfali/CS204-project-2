
package memorygamecards;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import memorygamecards.CodingChallenge;

public class MemoryGame extends JFrame {
    private ArrayList<Card> cards = new ArrayList<>();
    private Card firstCard, secondCard;
    private int matchesFound = 0;
    private int moves = 0;
    private JLabel movesLabel;
    private JLabel timerLabel;
    private Timer timer;
    private int timeElapsed = 0;
    private JPanel cardPanel;
    private JButton restartButton;
    private JButton exitButton;
    private int level;
    private int maxMoves;

    class Card extends JButton {
    String cardName;
    ImageIcon cardImageIcon;
    boolean isFlipped = false;

    Card(String cardName, ImageIcon cardImageIcon) {
        
        this.cardName = cardName;
        this.cardImageIcon = cardImageIcon;
        setPreferredSize(new Dimension(128, 128));
        setFocusable(false);
        setBackground(Color.black);
        setForeground(Color.WHITE);
        setFont(new Font("Arial", Font.BOLD, 20));
        setIcon(new ImageIcon("./img/digitalBack/.png")); 
        addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleCardClick(Card.this); 
            }
        });
    }

    public void flip() {
        if (isFlipped) {
            setIcon(new ImageIcon("./img/digitalBack/.png"));
            setBackground(Color.black);
        } else {
            setIcon(cardImageIcon); 
            setBackground(Color.WHITE); 
        }
        isFlipped = !isFlipped;
        
    }

    public String getCardName() {
        return cardName;
    }

    public boolean isFlipped() {
        return isFlipped;
    }
}

public MemoryGame() {
    setTitle("Memory Card Game");
    setSize(700, 700);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLayout(new BorderLayout());

    JPanel infoPanel = new JPanel();
    movesLabel = new JLabel("Moves: 0");
    timerLabel = new JLabel("Time: 0");
    infoPanel.add(movesLabel);
    infoPanel.add(timerLabel);

    add(infoPanel, BorderLayout.NORTH);

    String[] options = {"Easy", "Medium", "Hard"};
    level = JOptionPane.showOptionDialog(this, 
            "Select Difficulty Level", 
            "Memory Game",
            JOptionPane.DEFAULT_OPTION, 
            JOptionPane.INFORMATION_MESSAGE, 
            null, options, options[0]);

    switch (level) {
            case 0: // Easy
                maxMoves = 18; 
                break;
            case 1: // Medium
                maxMoves = 14; 
                break;
            case 2: // Hard
                maxMoves = 11; 
                break;
            default:
                maxMoves = 18; 
        }
    
    cardPanel = new JPanel();
    cardPanel.setLayout(new GridLayout(4, 8)); 

    createCards();
    Collections.shuffle(cards);

    for (Card card : cards) {
        cardPanel.add(card);
    }

    add(cardPanel, BorderLayout.CENTER);

    restartButton = new JButton("Restart");
    exitButton = new JButton("Exit");
    restartButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            restartGame();
        }
    });
    exitButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            new StartGame().setVisible(true);
            dispose();
        }
    });
    JPanel buttonPanel = new JPanel();
    buttonPanel.add(restartButton);
    buttonPanel.add(exitButton);
    add(buttonPanel, BorderLayout.SOUTH);

    startTimer();

    setVisible(true);

    showCardsForTwoSeconds();
}

private void createCards() {
    String[] cardNames = {
        "C#", "C++", "C", "JavaScript", 
        "css", "html", "java", "mysql", 
        "php", "python"
    };

    for (String cardName : cardNames) {
        ImageIcon cardImageIcon = new ImageIcon(getClass().getResource("./img/" + cardName + ".png"));
        cards.add(new Card(cardName, cardImageIcon));
        cards.add(new Card(cardName, cardImageIcon)); 
    }
}

private void showCardsForTwoSeconds() {
    for (Card card : cards) {
        card.flip(); 
    }
    Timer timer = new Timer(2000, new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            for (Card card : cards) {
                card.flip(); 
            }
        }
    });
    timer.setRepeats(false);
    timer.start();
}

private void handleCardClick(Card card) {
    if (firstCard == null) {
        firstCard = card;
        firstCard.flip();
    } else if (secondCard == null && card != firstCard) {
        secondCard = card;
        secondCard.flip();
        moves++; 
        movesLabel.setText("Moves: " + moves);
        checkForMatch();
    }
}

private void checkForMatch() {
    if (firstCard != null && secondCard != null) {
        if (firstCard.getCardName().equals(secondCard.getCardName())) {
            matchesFound++;
            firstCard = null;
            secondCard = null;

            if (matchesFound == cards.size() / 2) {
                timer.stop();
                new WellDone().setVisible(true);
                dispose();
            }
        } else {
            Timer flipBackTimer = new Timer(1000, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    firstCard.flip();
                    secondCard.flip();
                    firstCard = null;
                    secondCard = null;
                }
            });
            flipBackTimer.setRepeats(false);
            flipBackTimer.start();
        }
        if (moves == maxMoves) {
            new GameOver().setVisible(true);
            dispose();
            }
        }
    }

public void setTimeElapsed(int timeElapsed) {
        this.timeElapsed = timeElapsed;
        timerLabel.setText("Time: " + timeElapsed);
        startTimer(); 
    }

private void startTimer() {
    timer = new Timer(1000, new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            timeElapsed++;
            timerLabel.setText("Time: " + timeElapsed);
        }
    });
    timer.start();
}

private void restartGame() {
    matchesFound = 0;
    moves = 0;
    timeElapsed = 0;
    firstCard = null;
    secondCard = null;
    cards.clear();
    cardPanel.removeAll();

    createCards();
    Collections.shuffle(cards);

    for (Card card : cards) {
        cardPanel.add(card);
    }
    cardPanel.revalidate();
    cardPanel.repaint();

    movesLabel.setText("Moves: 0");
    timerLabel.setText("Time: 0");

    timer.stop();
    startTimer();
    showCardsForTwoSeconds();
}

public static void main(String[] args) {
    new MemoryGame();
    }
}